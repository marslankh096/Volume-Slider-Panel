package com.demo.volumeslider.view;


public interface OnclickInterface {
    void OnMyClick1(int i, Object obj);

    void OnMyClick2(int i, Object obj);
}
