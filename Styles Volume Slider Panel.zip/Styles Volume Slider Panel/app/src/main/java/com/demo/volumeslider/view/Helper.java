package com.demo.volumeslider.view;


public class Helper {
    public static int check;
}
